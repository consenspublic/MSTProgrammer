﻿namespace WindowsFormsApplication1
{
    partial class MH482
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MH482));
            this.buttonConnect = new System.Windows.Forms.Button();
            this.buttonDisconnect = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.listBoxPorts = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonScan = new System.Windows.Forms.Button();
            this.listBoxBaud = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBoxLEDCom = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.pictureBoxTestResult = new System.Windows.Forms.PictureBox();
            this.label23 = new System.Windows.Forms.Label();
            this.buttonDebug = new System.Windows.Forms.Button();
            this.listBoxCommands = new System.Windows.Forms.ListBox();
            this.label24 = new System.Windows.Forms.Label();
            this.textBoxResponse = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLEDCom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTestResult)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonConnect
            // 
            this.buttonConnect.Location = new System.Drawing.Point(12, 134);
            this.buttonConnect.Name = "buttonConnect";
            this.buttonConnect.Size = new System.Drawing.Size(75, 23);
            this.buttonConnect.TabIndex = 0;
            this.buttonConnect.Text = "Connect";
            this.buttonConnect.UseVisualStyleBackColor = true;
            this.buttonConnect.Click += new System.EventHandler(this.buttonConnect_Click);
            // 
            // buttonDisconnect
            // 
            this.buttonDisconnect.Enabled = false;
            this.buttonDisconnect.Location = new System.Drawing.Point(93, 134);
            this.buttonDisconnect.Name = "buttonDisconnect";
            this.buttonDisconnect.Size = new System.Drawing.Size(75, 23);
            this.buttonDisconnect.TabIndex = 1;
            this.buttonDisconnect.Text = "Disconnect";
            this.buttonDisconnect.UseVisualStyleBackColor = true;
            this.buttonDisconnect.Click += new System.EventHandler(this.buttonDisconnect_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 284);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(504, 77);
            this.textBox1.TabIndex = 2;
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // listBoxPorts
            // 
            this.listBoxPorts.FormattingEnabled = true;
            this.listBoxPorts.Location = new System.Drawing.Point(12, 88);
            this.listBoxPorts.Name = "listBoxPorts";
            this.listBoxPorts.ScrollAlwaysVisible = true;
            this.listBoxPorts.Size = new System.Drawing.Size(182, 30);
            this.listBoxPorts.TabIndex = 2;
            this.listBoxPorts.SelectedIndexChanged += new System.EventHandler(this.listBoxPorts_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select Port";
            // 
            // buttonScan
            // 
            this.buttonScan.Location = new System.Drawing.Point(12, 39);
            this.buttonScan.Name = "buttonScan";
            this.buttonScan.Size = new System.Drawing.Size(75, 22);
            this.buttonScan.TabIndex = 0;
            this.buttonScan.Text = "Scan Ports";
            this.buttonScan.UseVisualStyleBackColor = true;
            this.buttonScan.Click += new System.EventHandler(this.buttonScan_Click);
            // 
            // listBoxBaud
            // 
            this.listBoxBaud.FormattingEnabled = true;
            this.listBoxBaud.Items.AddRange(new object[] {
            "1200",
            "2400",
            "4800",
            "9600",
            "14600",
            "19200",
            "38400",
            "57600",
            "115200",
            "230400",
            "460800",
            "921600"});
            this.listBoxBaud.Location = new System.Drawing.Point(212, 49);
            this.listBoxBaud.Name = "listBoxBaud";
            this.listBoxBaud.ScrollAlwaysVisible = true;
            this.listBoxBaud.Size = new System.Drawing.Size(71, 43);
            this.listBoxBaud.TabIndex = 6;
            this.listBoxBaud.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AccessibleName = "Baud Rate";
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(209, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Baud Rate";
            // 
            // pictureBoxLEDCom
            // 
            this.pictureBoxLEDCom.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxLEDCom.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxLEDCom.InitialImage")));
            this.pictureBoxLEDCom.Location = new System.Drawing.Point(183, 134);
            this.pictureBoxLEDCom.Name = "pictureBoxLEDCom";
            this.pictureBoxLEDCom.Size = new System.Drawing.Size(36, 36);
            this.pictureBoxLEDCom.TabIndex = 8;
            this.pictureBoxLEDCom.TabStop = false;
            this.pictureBoxLEDCom.UseWaitCursor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(177, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 9;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(12, 268);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(122, 13);
            this.label22.TabIndex = 38;
            this.label22.Text = "Command Line Interface";
            // 
            // pictureBoxTestResult
            // 
            this.pictureBoxTestResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxTestResult.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxTestResult.InitialImage")));
            this.pictureBoxTestResult.Location = new System.Drawing.Point(477, 102);
            this.pictureBoxTestResult.Name = "pictureBoxTestResult";
            this.pictureBoxTestResult.Size = new System.Drawing.Size(36, 36);
            this.pictureBoxTestResult.TabIndex = 41;
            this.pictureBoxTestResult.TabStop = false;
            this.pictureBoxTestResult.UseWaitCursor = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(476, 86);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(37, 13);
            this.label23.TabIndex = 42;
            this.label23.Text = "Result";
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // buttonDebug
            // 
            this.buttonDebug.Location = new System.Drawing.Point(342, 98);
            this.buttonDebug.Name = "buttonDebug";
            this.buttonDebug.Size = new System.Drawing.Size(95, 40);
            this.buttonDebug.TabIndex = 43;
            this.buttonDebug.Text = "Send Command";
            this.buttonDebug.UseVisualStyleBackColor = true;
            this.buttonDebug.Click += new System.EventHandler(this.buttonDebug_Click);
            // 
            // listBoxCommands
            // 
            this.listBoxCommands.FormattingEnabled = true;
            this.listBoxCommands.Items.AddRange(new object[] {
            "help",
            "*idn?",
            "version",
            "baudrate",
            "purge\\x04",
            "sync",
            "write",
            "read",
            "storebyte",
            "storechip",
            "exit",
            "seth",
            "setl",
            "*rst",
            "reada",
            "i2cw",
            "i2cr"});
            this.listBoxCommands.Location = new System.Drawing.Point(345, 49);
            this.listBoxCommands.Name = "listBoxCommands";
            this.listBoxCommands.Size = new System.Drawing.Size(92, 43);
            this.listBoxCommands.TabIndex = 44;
            this.listBoxCommands.SelectedIndexChanged += new System.EventHandler(this.listBoxCommands_SelectedIndexChanged);
            // 
            // label24
            // 
            this.label24.AccessibleName = "S";
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(342, 33);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(89, 13);
            this.label24.TabIndex = 45;
            this.label24.Text = "Debug Command";
            this.label24.Click += new System.EventHandler(this.label24_Click);
            // 
            // textBoxResponse
            // 
            this.textBoxResponse.Location = new System.Drawing.Point(342, 160);
            this.textBoxResponse.Name = "textBoxResponse";
            this.textBoxResponse.Size = new System.Drawing.Size(171, 20);
            this.textBoxResponse.TabIndex = 46;
            // 
            // label25
            // 
            this.label25.AccessibleName = "S";
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(342, 144);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(55, 13);
            this.label25.TabIndex = 47;
            this.label25.Text = "Response";
            this.label25.Click += new System.EventHandler(this.label25_Click);
            // 
            // MH482
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(772, 397);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.textBoxResponse);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.listBoxCommands);
            this.Controls.Add(this.buttonDebug);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.pictureBoxTestResult);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBoxLEDCom);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.listBoxBaud);
            this.Controls.Add(this.buttonScan);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBoxPorts);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.buttonDisconnect);
            this.Controls.Add(this.buttonConnect);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.ImeMode = System.Windows.Forms.ImeMode.On;
            this.Name = "MH482";
            this.Text = "MH482";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLEDCom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTestResult)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonConnect;
        private System.Windows.Forms.Button buttonDisconnect;
        private System.Windows.Forms.TextBox textBox1;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.ListBox listBoxPorts;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonScan;
        private System.Windows.Forms.ListBox listBoxBaud;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBoxLEDCom;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.PictureBox pictureBoxTestResult;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button buttonDebug;
        private System.Windows.Forms.ListBox listBoxCommands;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBoxResponse;
        private System.Windows.Forms.Label label25;
    }
}

