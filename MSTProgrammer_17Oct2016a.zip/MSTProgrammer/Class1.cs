﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MSTProgrammer
{
    class ProgrammerCommand
    {
        string strCommand;
        string strResponse;

    }
}
